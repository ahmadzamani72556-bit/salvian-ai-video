"use client";

import Link from "next/link";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Button, Pill } from "@/components/ui";

export default function Register() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setError("");
    setLoading(true);
    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Unable to create the account.");
      router.push("/dashboard");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to create the account.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-[75vh] flex items-center justify-center">
      <Card className="w-full max-w-md">
        <Pill>GET STARTED</Pill>
        <h1 className="mt-4 text-3xl font-black">Create your creator account</h1>
        <form onSubmit={submit} className="mt-6 space-y-3">
          <input value={name} onChange={(e) => setName(e.target.value)} required minLength={2} autoComplete="name" className="w-full rounded-xl bg-black/20 border border-white/10 p-3" placeholder="Name" />
          <input value={email} onChange={(e) => setEmail(e.target.value)} required type="email" autoComplete="email" className="w-full rounded-xl bg-black/20 border border-white/10 p-3" placeholder="Email" />
          <input value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} type="password" autoComplete="new-password" className="w-full rounded-xl bg-black/20 border border-white/10 p-3" placeholder="Password (8+ characters)" />
          {error && <p className="text-sm text-red-300">{error}</p>}
          <Button primary disabled={loading} className="w-full">{loading ? "Creating account…" : "Create Account"}</Button>
        </form>
        <p className="mt-5 text-sm text-zinc-500">Already registered? <Link className="text-cyan-300" href="/login">Sign in</Link></p>
      </Card>
    </div>
  );
}
