import Link from "next/link";
import { Sparkles, Film, Clock3, Coins, ArrowUpRight } from "lucide-react";
import { Card, Button, Pill } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function Dashboard(){
  const user = await getCurrentUser();
  if (!user) return <div className="min-h-[70vh] flex items-center justify-center"><Card className="max-w-md w-full"><Pill>SALVIAN AI VIDEO</Pill><h1 className="mt-4 text-3xl font-black">Welcome back</h1><p className="mt-2 text-zinc-400">Sign in to access your creator dashboard.</p><Link href="/login" className="inline-flex mt-6"><Button primary>Sign In</Button></Link></Card></div>;
  const [projects, totalProjects] = await Promise.all([
    prisma.project.findMany({ where:{userId:user.id}, orderBy:{updatedAt:"desc"}, take:5 }),
    prisma.project.count({ where:{userId:user.id} })
  ]);
  const completed = await prisma.project.count({ where:{userId:user.id,status:"COMPLETED"} });
  const credits = user.creditAccount?.balance ?? 0;
  return <div className="space-y-7">
    <section className="relative overflow-hidden rounded-[2rem] p-7 lg:p-10 glass">
      <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-violet-600/20 blur-3xl"/>
      <Pill>AI YOUTUBE VIDEO GENERATOR</Pill>
      <h1 className="mt-5 text-4xl lg:text-6xl font-black tracking-tight">Halo, {user.name}.<br/><span className="gradient-text">Buat video berikutnya.</span></h1>
      <p className="mt-4 max-w-xl text-zinc-400">Ubah ide menjadi naskah, voice-over, visual, subtitle, thumbnail dan metadata YouTube.</p>
      <Link href="/create" className="inline-flex mt-7"><Button primary><Sparkles size={17} className="mr-2"/> Create New Video</Button></Link>
    </section>
    <div className="grid md:grid-cols-3 gap-4">
      <Card><Film size={20}/><div className="mt-5 text-2xl font-bold">{totalProjects}</div><div className="text-sm text-zinc-500">Videos Created</div></Card>
      <Card><Clock3 size={20}/><div className="mt-5 text-2xl font-bold">{completed}</div><div className="text-sm text-zinc-500">Completed Videos</div></Card>
      <Card><Coins size={20}/><div className="mt-5 text-2xl font-bold">{credits}</div><div className="text-sm text-zinc-500">Credits Remaining</div></Card>
    </div>
    <Card><div className="flex items-center justify-between mb-5"><div><h2 className="text-xl font-bold">Recent Projects</h2><p className="text-sm text-zinc-500">Your latest video projects</p></div><Link href="/projects" className="text-sm text-cyan-300 flex items-center gap-1">View all <ArrowUpRight size={15}/></Link></div>
      <div className="space-y-2">{projects.length===0 ? <div className="rounded-2xl bg-white/[.03] border border-white/5 p-6 text-sm text-zinc-500">Belum ada project. Buat video pertama Anda.</div> : projects.map(p=><div key={p.id} className="rounded-2xl bg-white/[.03] border border-white/5 p-4 flex items-center gap-4"><div className="h-12 w-20 rounded-xl bg-gradient-to-br from-violet-900 to-cyan-900"/><div className="flex-1"><div className="font-semibold">{p.title}</div><div className="text-xs text-zinc-500">{p.duration} min • {p.status}</div></div><Pill>{p.status}</Pill><Link href={`/editor?project=${p.id}`}><Button>Open</Button></Link></div>)}</div>
    </Card>
  </div>;
}
