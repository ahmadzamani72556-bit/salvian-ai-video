import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Authentication required." }, { status: 401 });
  const projects = await prisma.project.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: "desc" },
    take: 50,
  });
  return NextResponse.json({ projects });
}

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "Authentication required." }, { status: 401 });
    const body = await request.json();
    const title = String(body.title ?? "").trim();
    const topic = String(body.topic ?? "").trim();
    const duration = Number(body.duration ?? 5);
    const contentType = String(body.contentType ?? "Ceramah / Tasawuf").trim();
    const voice = String(body.voice ?? "Pria Dewasa — Tenang").trim();
    const visualStyle = String(body.visualStyle ?? "Cinematic").trim();
    if (title.length < 2) return NextResponse.json({ error: "Title is required." }, { status: 400 });
    if (!topic) return NextResponse.json({ error: "Video topic is required." }, { status: 400 });
    if (![5, 6, 7, 8].includes(duration)) return NextResponse.json({ error: "Duration must be 5–8 minutes." }, { status: 400 });

    const project = await prisma.project.create({
      data: { userId: user.id, title, topic, duration, contentType, voice, visualStyle },
    });
    return NextResponse.json({ project }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Unable to create project." }, { status: 500 });
  }
}
