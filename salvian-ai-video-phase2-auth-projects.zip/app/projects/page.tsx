import Link from "next/link";
import { Play } from "lucide-react";
import { Card, Button, Pill } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function Projects(){
  const user = await getCurrentUser();
  if (!user) return <div className="min-h-[70vh] flex items-center justify-center"><Card><Pill>AUTHENTICATION</Pill><h1 className="mt-4 text-3xl font-black">Sign in required</h1><Link href="/login" className="inline-flex mt-5"><Button primary>Sign In</Button></Link></Card></div>;
  const projects = await prisma.project.findMany({ where:{userId:user.id}, orderBy:{updatedAt:"desc"} });
  return <div className="space-y-5"><Pill>MY PROJECTS</Pill><h1 className="text-4xl font-black">Your video library</h1>{projects.length===0 ? <Card><p className="text-zinc-400">Belum ada project. Mulai dari satu ide.</p><Link href="/create" className="inline-flex mt-5"><Button primary>Create Video</Button></Link></Card> : <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{projects.map(p=><Card key={p.id}><div className="aspect-video rounded-2xl bg-gradient-to-br from-slate-950 via-violet-950/70 to-cyan-950 flex items-center justify-center"><Play/></div><div className="mt-4 flex items-center"><div><b>{p.title}</b><p className="text-xs text-zinc-500 mt-1">{p.duration} min • {p.status}</p></div><Link href={`/editor?project=${p.id}`} className="ml-auto"><Button>Open</Button></Link></div></Card>)}</div>}</div>
}
