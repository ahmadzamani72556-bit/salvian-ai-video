# SALVIAN AI VIDEO — Phase 2

This patch continues the Auth + Neon foundation with real dashboard data and project persistence.

## Includes
- Auth foundation (register/login/logout/session)
- Neon/PostgreSQL Prisma schema
- 100 welcome credits + credit ledger
- Real dashboard user/credit/project data
- Project GET/POST API
- Create Video saves a real project and opens the editor
- Real My Projects library

## Apply
Merge these files into the existing Codespace project. Keep `.env.local` unchanged.
Then run Prisma generate and Prisma db push, followed by a production build.
