# SALVIAN AI VIDEO — Auth foundation setup

This patch adds PostgreSQL/Neon-backed accounts, secure sessions, initial credits and project-ready database models without changing the existing visual design.

## One-time setup in Codespaces

1. Install dependencies: `npm install`
2. Generate Prisma Client: `npm run db:generate`
3. Push the schema to Neon. Because the connection is stored in `.env.local`, run: `set -a && source .env.local && set +a && npm run db:push`
4. Verify the app: `npm run build`

Do not paste the database connection string into chat or commit `.env.local`.
